/*
 * Catroid: An on-device visual programming system for Android devices
 * Copyright (C) 2010-2026 The Catrobat Team
 * (<http://developer.catrobat.org/credits>)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * An additional term exception under section 7 of the GNU Affero
 * General Public License, version 3, is available at
 * http://developer.catrobat.org/license_additional_term
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.catrobat.catroid.test.content.bricks

import org.catrobat.catroid.content.bricks.Brick
import org.catrobat.catroid.content.bricks.GoThroughBrick
import org.catrobat.catroid.content.bricks.VisualPlacementBrick
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GoThroughBrickTest {
    @Test
    fun testGoThroughBrickSupportsVisualPlacement() {
        val brick = GoThroughBrick()

        assertTrue(VisualPlacementBrick::class.java.isInstance(brick))
    }

    @Test
    fun testGoThroughBrickDefaultsToStartCoordinatesForVisualPlacement() {
        val brick = GoThroughBrick()

        assertTrue(VisualPlacementBrick::class.java.isInstance(brick))

        val visualPlacementBrick = brick as VisualPlacementBrick

        assertEquals(Brick.BrickField.X_POSITION, visualPlacementBrick.xBrickField)
        assertEquals(Brick.BrickField.Y_POSITION, visualPlacementBrick.yBrickField)
    }
}
